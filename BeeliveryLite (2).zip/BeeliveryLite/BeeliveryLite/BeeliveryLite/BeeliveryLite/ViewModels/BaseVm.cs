﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BeeliveryLite.ViewModels
{
    public class BaseVm
    {
        public abstract class BaseVmodel : BaseVm 
        {
           
        }
    }
}
