﻿using FunctionZero.CommandZero;
using FunctionZero.MvvmZero;
using BeeliveryLite.Pages;
using BeeliveryLite.ViewModels;
using System.Threading.Tasks;
using System.Windows.Input;

namespace BeeliveryLite.PageViewModels
{
    public class HomePageVm : BaseVm
    {
        private readonly IPageServiceZero _pageService;

        public ICommand PlaceOrderPageCommand { get; }

        public ICommand ViewBasketPageCommand { get; }

        public ICommand CheckoutPageCommand { get; }

        public ICommand OrderTrackingPageCommand { get; }

        public ICommand ShannonPageCommand { get; }

        public ICommand OliPageCommand { get; }

        public ICommand NathanPageCommand { get; 
        }
        public HomePageVm(IPageServiceZero pageService)
        {
            _pageService = pageService;
            PlaceOrderPageCommand = new CommandBuilder().SetExecuteAsync(PlaceOrderPageCommandExecuteAsync).SetName("Place Order").Build();
            ViewBasketPageCommand = new CommandBuilder().SetExecuteAsync(ViewBasketPageCommandExecuteAsync).SetName("View Basket").Build();
            CheckoutPageCommand = new CommandBuilder().SetExecuteAsync(CheckoutPageCommandExecuteAsync).SetName("Check Out").Build();
            OrderTrackingPageCommand = new CommandBuilder().SetExecuteAsync(OrderTrackingPageCommandExecuteAsync).SetName("Order Tracking").Build();
            ShannonPageCommand = new CommandBuilder().SetExecuteAsync(ShannonPageCommandExecuteAsync).SetName("Shannon Page").Build();
            NathanPageCommand = new CommandBuilder().SetExecuteAsync(NathanPageCommandExecuteAsync).SetName("Nathan Page").Build();
            OliPageCommand = new CommandBuilder().SetExecuteAsync(OliPageCommandExecuteAsync).SetName("Oli Page").Build();
        }

        public async Task PlaceOrderPageCommandExecuteAsync()
        {
            await _pageService.PushPageAsync<PlaceOrder, PlaceOrderVm>((vm) => {});
        }
        public async Task ViewBasketPageCommandExecuteAsync()
        {
            await _pageService.PushPageAsync<ViewBasket, ViewBasketVm>((vm) => {});
        }
        public async Task CheckoutPageCommandExecuteAsync()
        {
            await _pageService.PushPageAsync<Checkout, CheckoutVm>((vm) => { });
        }
        public async Task OrderTrackingPageCommandExecuteAsync()
        {
            await _pageService.PushPageAsync<OrderTracking, OrderTrackingVm>((vm) => { });
        }
        public async Task ShannonPageCommandExecuteAsync()
        {
            await _pageService.PushPageAsync<ShannonPage, ShannonPageVm>((vm) => { });
        }
        public async Task OliPageCommandExecuteAsync()
        {
            await _pageService.PushPageAsync<OliPage, OliPageVm>((vm) => { });
        }
        public async Task NathanPageCommandExecuteAsync()
        {
            await _pageService.PushPageAsync<NathanPage, NathanPageVm>((vm) => { });
        }
    }
}